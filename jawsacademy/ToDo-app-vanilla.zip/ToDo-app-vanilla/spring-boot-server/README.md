## Run Spring Boot application

1. start Postgres in docker-compose or podman-compose first:
```
docker-compose up
# alternatively, if using podman-compose
# podman-compose up
```
2. start the app
```
mvn spring-boot:run
```
